<!-- This Template states the absolute minimum for an MR.
    If you want to have a more elaborate template or know why we have this structure,
    please use the "Mixed Template" or consult the Wiki. -->
<!-- Add the CI labels to trigger the appropriate tests (e.g. "unit_test_esp32") --><!-- Mandatory -->
<!-- Make sure the commit message follows the Wiki about "Commit Messages" --><!-- Mandatory -->

<!-- Add description of the change here --><!-- Mandatory -->

## Related <!-- Optional -->
<!-- Related Jira issues and Github issues -->

## Release notes <!-- Mandatory -->
<!-- Either state release notes or write "No release notes" -->

<!-- ## Breaking change notes --><!-- Optional -->
